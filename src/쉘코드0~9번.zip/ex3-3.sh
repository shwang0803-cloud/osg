#!/bin/bash

echo "과목 점수들을 입력하세요:"
read -a scores   # 여러 개를 배열로 입력받기

sum=0
count=0

echo "각 점수에 대한 등급:"
for s in "${scores[@]}"
do
    # 각 점수 등급 출력
    if [ "$s" -ge 90 ]; then
        grade="A"
    else
        grade="B"
    fi
    echo "$s 점 → 등급: $grade"

    # 평균 계산을 위한 합/개수
    sum=$((sum + s))
    count=$((count + 1))
done

# 평균 점수 (정수로 처리)
avg=$((sum / count))

# 평균 등급
if [ "$avg" -ge 90 ]; then
    avg_grade="A"
else
    avg_grade="B"
fi

echo "-------------------------"
echo "평균 점수: $avg"
echo "평균 등급: $avg_grade"
