#!/bin/bash

DB="DB.txt"

# DB 파일이 없으면 미리 만들어두기
if [ ! -e "$DB" ]; then
    touch "$DB"
fi

while true
do
    echo "===================="
    echo "1) 팀원 정보 추가"
    echo "2) 팀원과 한 일 기록"
    echo "3) 팀원 검색"
    echo "4) 수행 내용 검색"
    echo "5) 종료"
    echo "===================="
    echo -n "메뉴 번호를 선택하세요: "
    read choice

    case "$choice" in
        1)
            echo -n "팀원 이름을 입력하세요: "
            read name
            echo -n "생일 또는 전화번호를 입력하세요: "
            read info
            # 형식: MEMBER | 이름 | 정보
            echo "MEMBER | 이름: $name | 정보: $info" >> "$DB"
            echo ">> 팀원 정보가 DB에 저장되었습니다."
            ;;

        2)
            echo -n "날짜를 입력하세요 (예: 2025-11-19): "
            read date
            echo -n "어떤 일을 했는지 입력하세요: "
            read work
            # 형식: LOG | 날짜 | 내용
            echo "LOG | 날짜: $date | 내용: $work" >> "$DB"
            echo ">> 수행 내용이 DB에 저장되었습니다."
            ;;

        3)
            echo -n "검색할 팀원 이름을 입력하세요: "
            read search_name
            echo ">> [$search_name] 으로 검색한 결과:"
            grep "$search_name" "$DB"
            ;;

        4)
            echo -n "검색할 날짜를 입력하세요 (예: 2025-11-19): "
            read search_date
            echo ">> [$search_date] 날짜로 검색한 결과:"
            grep "$search_date" "$DB"
            ;;

        5)
            echo "프로그램을 종료합니다."
            break
            ;;

        *)
            echo ">> 1~5 중에서 선택하세요."
            ;;
    esac

    echo   # 한 줄 띄우기
done

