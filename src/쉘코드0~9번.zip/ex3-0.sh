#!/bin/bash

echo 'export MYENV="Hello Shell"' >> ~/.bashrc
source ~/.bashrc

echo "등록된 환경변수 확인: $MYENV"

unset MYENV
echo "unset 후 값: $MYENV"
