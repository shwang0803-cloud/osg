#!/bin/bash

DB_DIR="./DB"
TRAIN_DIR="./train"

echo "== DB 폴더 확인 =="

if [ ! -d "$DB_DIR" ]; then
    echo "DB 폴더가 없습니다. 새로 생성합니다."
    mkdir "$DB_DIR"
else
    echo "DB 폴더가 이미 존재합니다."
fi

echo
echo "== DB 폴더에 5개 파일 생성 =="

for i in 1 2 3 4 5
do
    file_path="$DB_DIR/file${i}.txt"
    if [ ! -e "$file_path" ]; then
        echo "This is sample file $i" > "$file_path"
        echo "생성: $file_path"
    else
        echo "이미 존재: $file_path"
    fi
done

echo
echo "== DB 파일 압축 =="

tar -czf db_files.tar.gz -C "$DB_DIR" .
echo "압축 파일 생성: db_files.tar.gz"

echo
echo "== train 폴더 생성 및 링크 연결 =="

if [ ! -d "$TRAIN_DIR" ]; then
    echo "train 폴더가 없습니다. 새로 생성합니다."
    mkdir "$TRAIN_DIR"
else
    echo "train 폴더가 이미 존재합니다."
fi

for i in 1 2 3 4 5
do
    src="$DB_DIR/file${i}.txt"
    link="$TRAIN_DIR/file${i}.txt"
    ln -sf "$src" "$link"
    echo "링크 생성: $link -> $src"
done

echo
echo "== 작업 완료 =="

echo "DB 폴더 내용:"
ls -l "$DB_DIR"

echo
echo "train 폴더 내용 (링크 확인):"
ls -l "$TRAIN_DIR"
