#!/bin/bash

# 내부 함수 정의
run_ls() {
    # 함수로 전달된 모든 인자를 하나의 문자열로 취합
    opts="$*"

    echo "실행할 명령어: ls $opts"
    # eval을 사용해서 문자열을 실제 명령어로 실행
    eval "ls $opts"
}

# 스크립트 실행 시 넘겨받은 인자들을 그대로 함수에 전달
run_ls "$@"

