#!/bin/bash

echo "=== Shell 스크립트 시작 ==="

# 현재 스크립트에 들어온 인자들을 그대로 Python 파일에 넘겨줌
python3 ex3-6.py "$@"

echo "=== Shell 스크립트 종료 ==="
