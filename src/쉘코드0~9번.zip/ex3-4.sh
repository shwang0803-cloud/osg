#!/bin/bash

scores=()   # 점수를 저장할 배열

while true
do
    echo "===================="
    echo "1) 과목 성적 추가"
    echo "2) 입력된 모든 점수 보기"
    echo "3) 평균 점수 확인"
    echo "4) 평균 등급 (GPA) 변환"
    echo "5) 종료"
    echo "===================="
    echo -n "메뉴 번호를 선택하세요: "
    read choice

    case "$choice" in
        1)
            echo -n "추가할 점수를 입력하세요: "
            read s
            scores+=("$s")
            echo ">> 점수 $s 추가 완료"
            ;;

        2)
            if [ ${#scores[@]} -eq 0 ]; then
                echo ">> 아직 입력된 점수가 없습니다."
            else
                echo ">> 입력된 점수들: ${scores[@]}"
            fi
            ;;

        3)
            if [ ${#scores[@]} -eq 0 ]; then
                echo ">> 평균을 계산할 점수가 없습니다."
            else
                sum=0
                for v in "${scores[@]}"
                do
                    sum=$((sum + v))
                done
                avg=$((sum / ${#scores[@]}))
                echo ">> 평균 점수: $avg"
            fi
            ;;

        4)
            if [ ${#scores[@]} -eq 0 ]; then
                echo ">> 평균 등급을 계산할 점수가 없습니다."
            else
                sum=0
                for v in "${scores[@]}"
                do
                    sum=$((sum + v))
                done
                avg=$((sum / ${#scores[@]}))

                if [ "$avg" -ge 90 ]; then
                    gpa="A"
                elif [ "$avg" -ge 80 ]; then
                    gpa="B"
                elif [ "$avg" -ge 70 ]; then
                    gpa="C"
                elif [ "$avg" -ge 60 ]; then
                    gpa="D"
                else
                    gpa="F"
                fi

                echo ">> 평균 점수: $avg, 평균 등급(GPA): $gpa"
            fi
            ;;

        5)
            echo "프로그램을 종료합니다."
            break
            ;;

        *)
            echo ">> 1~5 중에서 선택하세요."
            ;;
    esac

    echo    # 한 줄 띄우기
done
