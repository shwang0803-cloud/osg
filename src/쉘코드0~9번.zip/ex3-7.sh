#!/bin/bash

while true
do
    echo "========================="
    echo "1) 사용자 정보"
    echo "2) CPU 사용률 확인"
    echo "3) 메모리 사용량 확인"
    echo "4) 디스크 사용량 확인"
    echo "5) 종료"
    echo "========================="
    echo -n "메뉴 번호를 선택하세요: "
    read choice

    case "$choice" in
        1)
            echo ">> 사용자 정보"
            whoami
            echo "현재 로그인 사용자들:"
            who
            ;;

        2)
            echo ">> CPU 사용률 (상위 프로세스)"
            # macOS용 (한 번만 찍고 끝)
            ps -A -o %cpu,command | sort -nr | head -5

            # 리눅스라면 대신 아래 사용 (주석 풀어서 사용)
            # top -b -n 1 | head -10
            ;;

        3)
            echo ">> 메모리 사용량"
            # macOS: vm_stat 사용
            vm_stat | head -10

            # 리눅스라면 대신 아래 사용 (주석 풀어서 사용)
            # free -h
            ;;

        4)
            echo ">> 디스크 사용량"
            df -h
            ;;

        5)
            echo "프로그램을 종료합니다."
            break
            ;;

        *)
            echo ">> 1~5 중에서 선택하세요."
            ;;
    esac

    echo   # 줄바꿈
done
