#!/bin/bash

echo "계산할 숫자를 입력하세요 (공백으로 여러 개 입력 가능):"
read -a numbers

for x in "${numbers[@]}"
do
    result=$(echo "0.5 * $x * $x" | bc -l)
    echo "x=$x → y=$result"
done
