import sys

print("=== Python 프로그램 시작 ===")

# sys.argv[0] 는 파일 이름이니까,
# 실제 인자는 sys.argv[1:] 에 들어있음
args = sys.argv[1:]

print("입력된 인자 개수:", len(args))
print("입력된 인자 목록:", args)

print("=== Python 프로그램 종료 ===")

